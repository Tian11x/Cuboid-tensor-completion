function [X_recover]=no_name_factorization(Row,Col,Dep,R)
%===================fenjie======================%

%================================================%
max_iter=1000; %���ĵ�������
iter=1;       %��ʼ����ǰ����
converge=0;   %������
threshold=10;
lambda=0.005;
error_old=0;
error_new=0;
Curve_loss=zeros(2,max_iter);


disp([ 'Row,Col,Dep : ' num2str( sum(sum(sum((Row~=0)))) ) ', ' num2str( sum(sum(sum((Col~=0)))) ) ', ' num2str( sum(sum(sum((Dep~=0)))) ) ]);
Row_1=double( tenmat(Row,1) ); Row_2=double( tenmat(Row,2) ); Row_3=double( tenmat(Row,3) ); %����ģʽչ��
Col_1=double( tenmat(Col,1) ); Col_2=double( tenmat(Col,2) ); Col_3=double( tenmat(Col,3) ); %����ģʽչ��
Dep_1=double( tenmat(Dep,1) ); Dep_2=double( tenmat(Dep,2) ); Dep_3=double( tenmat(Dep,3) ); %����ģʽչ��
%===============================�ع�=======================================%
%-------��ʼ�����Ӿ���
% Pr=cp_als( tensor(Row),R ); Pc=cp_als( tensor(Col),R ); Pd=cp_als( tensor(Dep),R );
% Ar=Pr.U{1}; Ac=Pc.U{1}; Ad=Pd.U{1}; 
% Br=Pr.U{2}; Bc=Pc.U{2}; Bd=Pd.U{2}; 
% Cr=Pr.U{3}; Cc=Pc.U{3}; Cd=Pd.U{3}; 
% Cr=KR_product(Pr.lambda',Pr.U{3}); Cc=KR_product(Pc.lambda',Pc.U{3}); Cd=KR_product(Pd.lambda',Pd.U{3});
[Ar,Br,Cr]=compare_cp_als( Row,ones(size(Row)),R ); 
[Ac,Bc,Cc]=compare_cp_als( Col,ones(size(Col)),R ); 
[Ad,Bd,Cd]=compare_cp_als( Dep,ones(size(Dep)),R );
% Ar=ones(size(Ar)); Ac=ones(size(Ac)); Ad=ones(size(Ad)); 
% Br=ones(size(Br)); Bc=ones(size(Bc)); Bd=ones(size(Bd)); 
% Cr=ones(size(Cr)); Cc=ones(size(Cc)); Cd=ones(size(Cd)); 




save Ar Ar
save Br Br
save Cr Cr
save Ac Ac
save Ad Ad
save Bc Bc
save Bd Bd
save Cc Cc
save Cd Cd

    %=====================�����ع�====================%
    X_recover=tensor_inner_fast(Ar,Bc,Cd); %
    [train_error,~]=tensor_recover_error(X,X_recover,IDX); %ѵ�����
    disp(['the train error of ' num2str(iter) '-th iteration is : ' num2str(train_error)]);
%-------�����������Ӿ���
while ~converge
    %====================�пռ�=====================%
    %==�������Ӿ���Ar====%
    CBr=KR_product(Cr,Br);  %��СΪ d^2 * R
    tmp = Row_1 * CBr * pinv( lambda*eye(R,R) + CBr'*CBr); %�������Ӿ���Ar 
    if norm(tmp)<threshold
        Ar=tmp;
    end
    
    %==�������Ӿ���Br====%
    CAr=KR_product(Cr,Ar);
    tmp = ( Row_2 * CAr + Bc(col_sta:col_end,:) + Bd ) * pinv( 2 * eye(R,R) + CAr'*CAr);
    if norm(tmp)<threshold
       Br=tmp;
    end
    
    %==�������Ӿ���Cr====%
    BAr=KR_product(Br,Ar);
    tmp = ( Row_3 * BAr + Cd(dep_sta:dep_end,:) + Cc ) * pinv( 2 * eye(R,R) + BAr'*BAr);   
    if norm(tmp)<threshold
       Cr=tmp;
    end
    %======================�пռ�===================%
    %==�������Ӿ���Ac====%
    CBc=KR_product(Cc,Bc);  %��СΪ (Jd) * R
    tmp = ( Col_1 * CBc + Ar(row_sta:row_end,:) + Ad ) * pinv( 2 * eye(R,R) + CBc'*CBc); % �������Ӿ���Ac 
    if norm(tmp)<threshold
       Ac=tmp;
    end
    %==�������Ӿ���Bc====%
    CAc=KR_product(Cc,Ac);
    tmp = ( Col_2 * CAc  ) * pinv(  lambda*eye(R,R) + CAc'*CAc );
    if norm(tmp)<threshold
       Bc=tmp;
    end
    %==�������Ӿ���Cc====%
    BAc=KR_product(Bc,Ac);
    tmp = ( Col_3 * BAc + Cd(dep_sta:dep_end,:) + Cr ) * pinv( 2 * eye(R,R) + BAc'*BAc);  
    if norm(tmp)<threshold
       Cc=tmp;
    end    
    %=====================tubal�ռ�==================%
    %==�������Ӿ���Ar====%
    CBd=KR_product(Cd,Bd);  %��СΪ d^2 * R
    tmp = ( Dep_1 * CBd + Ar(row_sta:row_end,:) + Ac ) * pinv( 2 * eye(R,R) + CBd'*CBd); %�������Ӿ���Ar 
    if norm(tmp)<threshold
       Ad=tmp;
    end     
    %==�������Ӿ���Br====%
    CAd=KR_product(Cd,Ad);
    tmp = ( Dep_2 * CAd + Bc(col_sta:col_end,:) + Br ) * pinv( 2 * eye(R,R) + CAd'*CAd);
    if norm(tmp)<threshold
       Bd=tmp;
    end    
    %==�������Ӿ���Cr====%
    BAd=KR_product(Bd,Ad);
    tmp = ( Dep_3 * BAd ) * pinv(  lambda*eye(R,R) + BAd'*BAd );  
    if norm(tmp)<threshold
       Cd=tmp;
    end    
    disp(['norm(Ar): ' num2str(norm(Ar))]);
    disp(['norm(Ac): ' num2str(norm(Ac))]);
    disp(['norm(Ad): ' num2str(norm(Ad))]);
    disp(['norm(Br): ' num2str(norm(Br))]);
    disp(['norm(Bc): ' num2str(norm(Bc))]);
    disp(['norm(Bd): ' num2str(norm(Bd))]);
    disp(['norm(Cr): ' num2str(norm(Cr))]);
    disp(['norm(Cc): ' num2str(norm(Cc))]);
    disp(['norm(Cd): ' num2str(norm(Cd))]);
    %=====================�����ع�====================%
    X_recover=tensor_inner_fast(Ar,Bc,Cd); %
    [train_error,test_error]=tensor_recover_error(X,X_recover,IDX); %ѵ�����
    disp(['the train error of ' num2str(iter) '-th iteration is : ' num2str(train_error)]);
    error_new=train_error;
    res_error=abs(error_old-error_new);
    %=====================�ж��Ƿ�����==================%
    if max_iter<iter || res_error<10^-11
        converge=1;
    end
    error_old=error_new;
    
    Curve_loss(1,iter)=train_error;
    Curve_loss(2,iter)=test_error;
    iter=iter+1;
end
X_recover=tensor_inner_fast(Ar,Bc,Cd); %