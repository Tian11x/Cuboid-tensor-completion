function [Error,Time1,Sample_ratio]=experiment_different_sample_algorithm(Tensor,R,repeat)
[I,J,K]=size(Tensor);  % ��������Ĵ�С
sample_ratio=0.1*repeat;% ���ò�����
d=1+repeat;    %����d�ô�С
lambda=0.01; threshold=10; %my_cp_als���� ����
%===================��������=================%
%------------ adaptive Fiber ���� -----------%

[P_A,IDX_A,time_A1,time_A]=tensor_adaptive_sample_fiber(Tensor,I*J*sample_ratio,0.6,floor(J*sample_ratio),R); %���� + �ع�

UIDX_A=ones(I,J,K)-IDX_A;

%------------- Leverage ���� ----------------%
tic;
[IDX_L]=tensor_leverage_sample_entry(Tensor,I*J*K*sample_ratio,0.9,R); %����
% [P_L]=tensor_ADMM(Tensor,IDX_L,rho);  %ADMM�ع�
opts.mu = 1e-3; opts.tol = 1e-7; opts.rho = 1.1; opts.max_iter = 500; opts.DEBUG = 0; opts.max_mu = 1e10;
gamma = 1/sqrt(max(I,J)*K);
time_L1=toc;
tic;
[P_L]=tensor_nuclear_ADMM(Tensor.*IDX_L,gamma,opts);
time_L=toc;
UIDX_L=ones(I,J,K)-IDX_L;

%------------- block ���� -----------------%
d1=min(d, floor( min( [I,J,K])/2));
tic;
[ID,JD,KD]=tensor_block_divide(I,J,K,d1);  % �����ֿ�
[IDX_B,Dictionary]=tensor_block_sample(ID,JD,KD,I,J,K,Tensor);  % ����
time_B1=toc;
tic;
[P_B]=tensor_block_completion(Tensor.*IDX_B,IDX_B,R,KD,Dictionary,lambda,threshold); %�ع�
% [U,S,V]=compare_cp_als(Tensor,IDX_B,4);  %�ع�
% P_B=tensor_inner_fast(U,S,V);
time_B=toc; 
UIDX_B=ones(I,J,K)-IDX_B;

%------------- tube������� ----------------%
tic;
[IDX_T]=tensor_random_sample_tube(zeros(I,J,K),(I*J*sample_ratio));% ����
% [U,S,V]=tSVD(Tensor.*IDX_T);  % �ع�
% P_T= tensor_product_Fourier( tensor_product_Fourier(U,S),tensor_transpose(V) );
gamma = 1/sqrt(max(I,J)*K);
time_T1=toc;
% [P_T]=tensor_nuclear_ADMM(Tensor.*IDX_T,gamma,opts);

tic;
[U,S,V]=my_cp_als(Tensor.*IDX_T,IDX_T,R,lambda,threshold);  %�ع�
P_T=tensor_inner_fast(U,S,V);
time_T=toc;
UIDX_T=ones(I,J,K)-IDX_T;

%------------- entry������� ---------------%
tic;
[IDX_R]=tensor_random_sample_entry(I,J,K,(I*J*K)*sample_ratio);  %����
time_R1=toc;
%-1.
% [P_R]=cp_als( tensor(Tensor.*IDX_R),R);          %�ع�
% P_R=double(P_R);
%-2.
tic;
[U,S,V]=my_cp_als(Tensor.*IDX_R,IDX_R,R,lambda,threshold);  %�ع�
P_R=tensor_inner_fast(U,S,V);
time_R=toc;
UIDX_R=ones(I,J,K)-IDX_R;

%------------- ���� tube ����� ---------------%

d2=min(d, floor( min( [I,J,K])/2));
R1=min(2,R);
tic;
[ID,JD,KD]=tensor_block_divide(I,J,K,d2);  % �����ֿ�
[IDX_K,Dictionary_K]=tensor_block_sample_fiber(ID,JD,I,J,K);  % ����
[P_K]=tensor_block_completion_fiber(Tensor,IDX_K,R1,ID,JD,Dictionary_K);% �ع�
time_K=toc;
UIDX_K=ones(I,J,K)-IDX_K;

%-------------- ����6����� ---------------%
d3=min(d, floor( min( [I,J,K])));
max_iter=50;
max_sub_iter=10;
tic;
[ID,JD,KD]=tensor_block_divide(I,J,K,d3);  % �����ֿ�
[IDX_C,dictionary]=tensor_block_sample_cur(I,J,K,ID,JD,KD); % ��������
[P_C]=tensor_block_completion_cur1(Tensor,IDX_C,dictionary,max_iter,R);
% [P_C]=tensor_block_completion_cur2(Tensor,IDX_C,dictionary,max_iter,max_sub_iter,R); % �����ع�
time_C=toc;
UIDX_C=ones(size(IDX_C))-IDX_C;

%=============================������====================================%
Error_A=sqrt( sum(sum(sum( ((P_A-Tensor).*UIDX_A).^2 ))) / sum(sum(sum( ((Tensor).*UIDX_A).^2  ))) );
sample_ratio_A=sum(sum(sum(IDX_A))) / (I*J*K); %���������
Error_L=sqrt( sum(sum(sum( ((P_L-Tensor).*UIDX_L).^2 ))) / sum(sum(sum( ((Tensor).*UIDX_L).^2  ))) );
sample_ratio_L=sum(sum(sum(IDX_L))) / (I*J*K); %���������
Error_B=sqrt( sum(sum(sum( ((P_B-Tensor).*UIDX_B).^2 ))) / sum(sum(sum( ((Tensor).*UIDX_B).^2  ))) );
sample_ratio_B=sum(sum(sum(IDX_B))) / (I*J*K); %���������
Error_T=sqrt( sum(sum(sum( ((P_T-Tensor).*UIDX_T).^2 ))) / sum(sum(sum( ((Tensor).*UIDX_T).^2  ))) );
sample_ratio_T=sum(sum(sum(IDX_T))) / (I*J*K); %���������
Error_R=sqrt( sum(sum(sum( ((P_R-Tensor).*UIDX_R).^2 ))) / sum(sum(sum( ((Tensor).*UIDX_R).^2  ))) );
sample_ratio_R=sum(sum(sum(IDX_R))) / (I*J*K); %���������
Error_K=sqrt( sum(sum(sum( ((P_K-Tensor).*UIDX_K).^2 ))) / sum(sum(sum( ((Tensor).*UIDX_K).^2  ))) );
sample_ratio_K=sum(sum(sum(IDX_K))) / (I*J*K); %���������
% Error_C=sqrt( sum(sum(sum( ((P_C-Tensor).*UIDX_C).^2 ))) / sum(sum(sum( ((Tensor).*UIDX_C).^2  ))) );
% sample_ratio_C=sum(sum(sum(IDX_C))) / (I*J*K); %���������
%========================================================================%
Error=[Error_A;Error_L;Error_B;Error_T;Error_R;Error_K];
Time1=[time_A1;time_L1;time_B1;time_T1;time_R1;time_K];
Time=[time_A;time_L;time_B;time_T;time_R;];

Sample_ratio=[sample_ratio_A;sample_ratio_L;sample_ratio_B;sample_ratio_T;sample_ratio_R;sample_ratio_K];